# PersonalOS - Week 1 MVP
**Your ADHD-Friendly Execution System for the 90-Email Challenge**

## What This Does

This is a **minimally viable** Personal OS designed for ONE purpose:
**Help you send 90 emails in 5 days and prove you can make shit happen.**

It has ONE command: `today`

That command generates a `Today.md` file with:
- Your daily email target (15/20/20/20/15)
- Progress toward 90 total
- Checklists to keep you on track
- Space to log resistance and wins

**That's it. No complexity. No rabbit holes. Just execution.**

---

## Setup (10 minutes)

### 1. Move to Home Directory
```bash
# Download the PersonalOS folder to your home directory
# It should be at: ~/PersonalOS/
```

### 2. Run Setup Script
```bash
cd ~/PersonalOS
chmod +x setup.sh
./setup.sh
```

This will:
- Make the `generate_today.py` script executable
- Add a `today` alias to your shell config (.zshrc or .bashrc)

### 3. Activate the Alias
```bash
# For zsh (default on modern Macs)
source ~/.zshrc

# For bash
source ~/.bashrc
```

### 4. Test It
```bash
today
```

You should see: "✅ Today.md generated successfully!"

### 5. Open Today.md
```bash
open ~/PersonalOS/Tasks/Today.md
```

Or if you have Obsidian:
- Open Obsidian
- Add `~/PersonalOS` as a vault
- Navigate to `Tasks/Today.md`

---

## Daily Workflow

### Every Morning (2 minutes)

1. **Run the command:**
   ```bash
   today
   ```

2. **Open the file:**
   ```bash
   open ~/PersonalOS/Tasks/Today.md
   ```
   (or open in Obsidian if you prefer)

3. **Read your mission** for the day

4. **Start executing**

### During the Day

- Check off boxes as you send emails
- Log when resistance shows up
- Track your wins

### End of Day (5 minutes)

1. **Update your tracker:**
   ```bash
   open ~/PersonalOS/Tasks/DecoponATX_Week1.md
   ```

2. **Update the "Completed" count** for today

3. **Save the file**

4. **Run `today` again tomorrow** - it will show your updated progress

---

## File Structure

```
~/PersonalOS/
├── Tasks/
│   ├── DecoponATX_Week1.md    # Master tracker (you update this)
│   └── Today.md                # Generated daily (don't edit directly)
└── Scripts/
    └── generate_today.py       # The magic (don't need to touch this)
```

---

## Important Rules (ADHD Protection)

### ✅ DO:
- Run `today` every morning
- Update `DecoponATX_Week1.md` with your daily email count
- Log resistance and wins in `Today.md`
- Celebrate every small win

### ❌ DON'T:
- Edit `Today.md` directly (it gets regenerated)
- Try to "optimize" or "improve" the system during Week 1
- Add features or integrations
- Spend time customizing (that's the hyperfocus trap)

**The system is INTENTIONALLY simple. Don't make it complex.**

---

## After Week 1

If you successfully sent 90 emails, THEN we build the full Personal OS:
- Trello integration
- Research automation
- Writing workflows
- Modular context system

**But not before you prove execution.**

---

## Troubleshooting

### "today" command not found
```bash
# Re-run the setup
cd ~/PersonalOS
./setup.sh

# Then reload your shell config
source ~/.zshrc  # or ~/.bashrc
```

### Python error
```bash
# Make sure Python 3 is installed
python3 --version

# If not installed, install it:
# Mac: brew install python3
# Linux: sudo apt-get install python3
```

### Can't find Today.md
```bash
# It's at this exact location:
~/PersonalOS/Tasks/Today.md

# Open it with:
open ~/PersonalOS/Tasks/Today.md
```

---

## The Real Purpose

This system isn't about productivity porn.

It's about proving to that 5-year-old at the carousel that:
**You CAN make shit happen.**

Every morning you run `today`.
Every day you check those boxes.
Every evening you update your progress.

By Friday, you'll have evidence.

**Now go execute.**
